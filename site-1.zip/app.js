(function () {
  var TG = "https://t.me/NeuroPhotoKadr_bot?start=";
  var MX = "https://max.ru/se14962038_bot?start=";

  function payload(src, tpl) {
    var p = "src_site" + (src || "");
    if (tpl) p += "_t-" + tpl;
    return p;
  }
  function link(where, src, tpl) {
    return (where === "max" ? MX : TG) + payload(src, tpl);
  }
  function toast(text) {
    var t = document.querySelector(".toast");
    if (!t) { t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
    t.textContent = text; t.classList.add("on");
    clearTimeout(t._h); t._h = setTimeout(function () { t.classList.remove("on"); }, 4200);
  }
  function copy(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text).catch(function () {});
    var a = document.createElement("textarea"); a.value = text; document.body.appendChild(a); a.select();
    try { document.execCommand("copy"); } catch (e) {} a.remove(); return Promise.resolve();
  }
  function goal(name) { try { if (window.ym && window.YM_ID) ym(window.YM_ID, "reachGoal", name); } catch (e) {} }

  // Кнопки с data-go="tg|max" — ссылка в бот с нужным стилем
  document.querySelectorAll("[data-go]").forEach(function (a) {
    a.href = link(a.dataset.go, a.dataset.src || document.body.dataset.src, a.dataset.tpl);
    a.target = "_blank"; a.rel = "noopener";
    a.addEventListener("click", function () { goal("open_" + a.dataset.go); });
  });

  // Конструктор: выбор, что сделать → кнопка Telegram / MAX
  document.querySelectorAll("form.maker").forEach(function (f) {
    f.addEventListener("submit", function (e) { e.preventDefault(); });
    f.querySelectorAll("button[data-where]").forEach(function (b) {
      b.addEventListener("click", function () {
        var c = f.querySelector("input[name=what]:checked");
        var tpl = c ? c.value : "";
        goal("maker_" + b.dataset.where);
        window.open(link(b.dataset.where, document.body.dataset.src, tpl), "_blank", "noopener");
      });
    });
  });

  // Именная открытка: собираем имя, увлечения и текст → копируем → открываем бот
  document.querySelectorAll("form.bday").forEach(function (f) {
    f.addEventListener("submit", function (e) { e.preventDefault(); });
    f.querySelectorAll("button[data-where]").forEach(function (b) {
      b.addEventListener("click", function () {
        var name = (f.name.value || "").trim();
        var hob = Array.prototype.map.call(f.querySelectorAll("input[name=hobby]:checked"), function (x) { return x.value; });
        var own = (f.hobby_own.value || "").trim(); if (own) hob.push(own);
        var text = (f.wish.value || "").trim();
        var memo = "Имя: " + (name || "-") + "\nУвлечения: " + (hob.join(", ") || "-") + "\nНадпись: " + (text || (name ? "С днём рождения, " + name + "!" : "С днём рождения!"));
        copy(memo).then(function () {
          toast("Данные открытки скопированы. Бот спросит имя, увлечения и текст — просто вставляйте ответы.");
        });
        goal("bday_" + b.dataset.where);
        setTimeout(function () { window.open(link(b.dataset.where, document.body.dataset.src, "bday_custom"), "_blank", "noopener"); }, 400);
      });
    });
  });

  // Заявка для компаний: текст копируется, бот принимает заявку и пересылает владельцу
  document.querySelectorAll("form.b2b").forEach(function (f) {
    f.addEventListener("submit", function (e) { e.preventDefault(); });
    f.querySelectorAll("button[data-where]").forEach(function (b) {
      b.addEventListener("click", function () {
        if (!f.task.value.trim()) { f.task.focus(); toast("Опишите задачу хотя бы в двух словах"); return; }
        var memo = "Заявка с сайта\nКто: " + (f.who.value || "-") + "\nКонтакт: " + (f.contact.value || "-") + "\nЗадача: " + f.task.value.trim();
        copy(memo).then(function () { toast("Заявка скопирована — вставьте её одним сообщением в чат с ботом."); });
        goal("b2b_" + b.dataset.where);
        setTimeout(function () { window.open((b.dataset.where === "max" ? MX : TG) + "src_siteB2b_b2b", "_blank", "noopener"); }, 400);
      });
    });
  });

  // Копирование промтов
  document.querySelectorAll(".prompt").forEach(function (p) {
    var b = document.createElement("button"); b.type = "button"; b.textContent = "Копировать";
    b.addEventListener("click", function () {
      copy(p.querySelector("span").textContent).then(function () { b.textContent = "Скопировано ✓"; toast("Промт скопирован. В боте нажмите «✍️ Свой запрос» и вставьте."); });
    });
    p.appendChild(b);
  });
})();
