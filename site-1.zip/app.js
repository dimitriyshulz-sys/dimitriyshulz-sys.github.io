(function () {
  var TG = "https://t.me/NeuroPhotoKadr_bot?start=";
  var MX = "https://max.ru/se14962038_bot?start=";

  function payload(src, tpl) {
    var p = "src_site" + (src || "");
    if (tpl) p += "_t-" + tpl;
    return p;
  }
  function link(where, src, tpl) {
    return (where === "max" ? MX : TG) + payload(src, tpl);
  }
  function toast(text) {
    var t = document.querySelector(".toast");
    if (!t) { t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
    t.textContent = text; t.classList.add("on");
    clearTimeout(t._h); t._h = setTimeout(function () { t.classList.remove("on"); }, 4200);
  }
  function copy(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text).catch(function () {});
    var a = document.createElement("textarea"); a.value = text; document.body.appendChild(a); a.select();
    try { document.execCommand("copy"); } catch (e) {} a.remove(); return Promise.resolve();
  }
  function goal(name) { try { if (window.ym && window.YM_ID) ym(window.YM_ID, "reachGoal", name); } catch (e) {} }

  // Кнопки с data-go="tg|max" — ссылка в бот с нужным стилем
  document.querySelectorAll("[data-go]").forEach(function (a) {
    a.href = link(a.dataset.go, a.dataset.src || document.body.dataset.src, a.dataset.tpl);
    a.target = "_blank"; a.rel = "noopener";
    a.addEventListener("click", function () { goal("open_" + a.dataset.go); });
  });

  // Конструктор: выбор, что сделать → кнопка Telegram / MAX
  document.querySelectorAll("form.maker").forEach(function (f) {
    f.addEventListener("submit", function (e) { e.preventDefault(); });
    f.querySelectorAll("button[data-where]").forEach(function (b) {
      b.addEventListener("click", function () {
        var c = f.querySelector("input[name=what]:checked");
        var tpl = c ? c.value : "";
        goal("maker_" + b.dataset.where);
        window.open(link(b.dataset.where, document.body.dataset.src, tpl), "_blank", "noopener");
      });
    });
  });

  // Именная открытка: имя, увлечения и надпись кодируются в ссылку запуска (схема = card_codec.py в боте)
  var SYMS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  var CHARS = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя 0123456789!,.?:-'\"()+%";
  var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  var HOB = ["рыбалка", "дача и сад", "путешествия", "кулинария", "спорт", "музыка", "книги", "машины", "охота", "вязание", "футбол", "танцы"];
  function enc(str) { var o = ""; str = (str || "").toLowerCase().replace(/\s+/g, " ").trim();
    for (var i = 0; i < str.length; i++) { var k = CHARS.indexOf(str[i]); if (k >= 0) o += SYMS[k]; } return o; }
  function cardPayload(f) {
    var mask = 0; Array.prototype.forEach.call(f.querySelectorAll("input[name=hobby]:checked"), function (x) { var k = HOB.indexOf(x.value); if (k >= 0) mask |= 1 << k; });
    return "pc" + B64[mask >> 6] + B64[mask & 63] + enc(f.name.value) + "_" + enc(f.hobby_own.value) + "_" + enc(f.wish.value);
  }
  document.querySelectorAll("form.bday").forEach(function (f) {
    f.addEventListener("submit", function (e) { e.preventDefault(); });
    var cnt = f.querySelector(".cnt-left");
    function upd() {
      var p = cardPayload(f), left = 64 - p.length;
      if (cnt) { cnt.textContent = left >= 0 ? "Осталось символов: " + left : "Слишком длинно — сократите на " + (-left); cnt.style.color = left < 0 ? "#D93A3A" : ""; }
      var bad = /[a-z]/i.test(f.name.value + f.hobby_own.value + f.wish.value);
      var w = f.querySelector(".lat-warn"); if (w) w.style.display = bad ? "block" : "none";
      return left;
    }
    f.addEventListener("input", upd); f.addEventListener("change", upd); upd();
    f.querySelectorAll("button[data-where]").forEach(function (b) {
      b.addEventListener("click", function () {
        if (upd() < 0) { toast("Текст получился длинным — сократите надпись или увлечение"); return; }
        goal("bday_" + b.dataset.where);
        window.open((b.dataset.where === "max" ? MX : TG) + cardPayload(f), "_blank", "noopener");
        toast("Открываем бота — останется только прислать фото именинника");
      });
    });
  });

  // Заявка для компаний: текст копируется, бот принимает заявку и пересылает владельцу
  document.querySelectorAll("form.b2b").forEach(function (f) {
    f.addEventListener("submit", function (e) { e.preventDefault(); });
    f.querySelectorAll("button[data-where]").forEach(function (b) {
      b.addEventListener("click", function () {
        if (!f.task.value.trim()) { f.task.focus(); toast("Опишите задачу хотя бы в двух словах"); return; }
        var memo = "Заявка с сайта\nКто: " + (f.who.value || "-") + "\nКонтакт: " + (f.contact.value || "-") + "\nЗадача: " + f.task.value.trim();
        copy(memo).then(function () { toast("Заявка скопирована — вставьте её одним сообщением в чат с ботом."); });
        goal("b2b_" + b.dataset.where);
        setTimeout(function () { window.open((b.dataset.where === "max" ? MX : TG) + "src_siteB2b_b2b", "_blank", "noopener"); }, 400);
      });
    });
  });

  // Копирование промтов
  document.querySelectorAll(".prompt").forEach(function (p) {
    var b = document.createElement("button"); b.type = "button"; b.textContent = "Копировать";
    b.addEventListener("click", function () {
      copy(p.querySelector("span").textContent).then(function () { b.textContent = "Скопировано ✓"; toast("Промт скопирован. В боте нажмите «✍️ Свой запрос» и вставьте."); });
    });
    p.appendChild(b);
  });
})();
